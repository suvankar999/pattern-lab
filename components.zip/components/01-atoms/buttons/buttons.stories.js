// Buttons Stories
import button from './button.twig';
import btn from './btn.twig';

import buttonData from './button.yml';
import btnData from './btn.yml';
import buttonAltData from './button-alt.yml';

/**
 * Storybook Definition.
 */
export default { title: 'Atoms/Button' };

export const twig = () => button(buttonData);

export const BTN = () => btn(btnData);

export const twigAlt = () => button(buttonAltData);
