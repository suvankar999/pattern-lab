import customlink from './customlink.twig';

import customlinkData from './customlink.yml';

/**
 * Storybook Definition.
 */
export default { title: 'Atoms/Links' };

export const customlinks = () => customlink(customlinkData);
