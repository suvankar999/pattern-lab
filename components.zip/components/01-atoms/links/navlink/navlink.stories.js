import navlink from './navlink.twig';
import navlinkData from './navlink.yml';

export default { title: 'Atoms/Links' };
export const NavbarText = () => navlink(navlinkData);
