import demolink from './demolink.twig';

import demolinkData from './demolink.yml';

/**
 * Storybook Definition.
 */
export default { title: 'Atoms/Links' };

export const demolinks = () => demolink(demolinkData);
