import card from './card.twig';
import numbercard from './numbercard/numbercard.twig';
import designer from './designer/designer.twig';
import cardData from './card.yml';
import designerData from './designer/designer.yml';
import numbercardData from './numbercard/numbercard.yml';
import cardBgData from './card-bg.yml';
import './designer/designer.scss';
/**
 * Storybook Definition.
 */
export default { title: 'Molecules/Cards' };

export const cardExample = () => card(cardData);

export const NumberCard = () => numbercard(numbercardData);

export const designerCard = () => designer(designerData);

export const cardWithBackground = () => card({ ...cardData, ...cardBgData });
