import grid from './grid.twig';
import gridtext from './gridtext/gridtext.twig';
import IMGgrid from './IMGgrid/IMGgrid.twig';
import imgcolumn from './imgcolumn/imgcolumn.twig';
import skill from './skill/skill.twig';

import gridData from './grid.yml';
import IMGgridData from './IMGgrid/IMGgrid.yml';
import imgcolumnData from './imgcolumn/imgcolumn.yml';
import gridtextData from './gridtext/gridtext.yml';
import skillData from './skill/skill.yml';
import './gridtext/gridtext.scss';
import './IMGgrid/IMGgrid.scss';
import './skill/skill.scss';
import './imgcolumn/imgcolumn.scss';
/**
 * Storybook Definition.
 */

export default { title: 'Organisms/Grids' };

export const defaultGrid = () => grid(gridData);

export const GridSection = () => gridtext(gridtextData);

export const IMGGridSection = () => IMGgrid(IMGgridData);

export const IMGColumn = () => imgcolumn(imgcolumnData);

export const MySkill = () => skill(skillData);
