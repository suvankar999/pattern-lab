import grid from './grid.twig';
import gridtext from './gridtext/gridtext.twig';
import IMGgrid from './IMGgrid/IMGgrid.twig';
import imgcolumn from './imgcolumn/imgcolumn.twig';
import skill from './skill/skill.twig';
import award from './award/award.twig';
import cardgrid from './cardgrid/cardgrid.twig';
import imgsection from './imgsection/imgsection.twig';
import parallax from './parallax/parallax.twig';

import gridData from './grid.yml';
import IMGgridData from './IMGgrid/IMGgrid.yml';
import imgcolumnData from './imgcolumn/imgcolumn.yml';
import gridtextData from './gridtext/gridtext.yml';
import skillData from './skill/skill.yml';
import awardData from './award/award.yml';
import cardgridData from './cardgrid/cardgrid.yml';
import parallaxData from './parallax/parallax.yml';
import imgsectionData from './imgsection/imgsection.yml';
import './gridtext/gridtext.scss';
import './IMGgrid/IMGgrid.scss';
import './skill/skill.scss';
import './imgcolumn/imgcolumn.scss';
import './cardgrid/cardgrid.scss';
import './award/award.scss';
import './parallax/parallax.scss';
/**
 * Storybook Definition.
 */

export default { title: 'Organisms/Grids' };

export const defaultGrid = () => grid(gridData);

export const GridSection = () => gridtext(gridtextData);

export const IMGGridSection = () => IMGgrid(IMGgridData);

export const IMGColumn = () => imgcolumn(imgcolumnData);

export const MySkill = () => skill(skillData);

export const AwardsHonors = () => award(awardData);

export const GridCard = () => cardgrid(cardgridData);

export const ImgSection = () => imgsection(imgsectionData);

export const ParallaxSection = () => parallax(parallaxData);
