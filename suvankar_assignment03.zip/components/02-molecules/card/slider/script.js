const card = ($) => {
  Drupal.behaviors.card = {
    attach(context) {
      const $context = $(context);
      $context.find('.my_slider').slick({
        arrows: false,
        autoplay: true,
        autoplaySpeed: 1000,
        infinite: true,
        dots: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              arrows: true,
              dots: false,
              infinite: false,
            },
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              arrows: true,
              dots: false,
              infinite: false,
            },
          },
        ],
      });
    },
  };
};
card(jQuery);
